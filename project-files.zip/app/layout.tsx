import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';

const inter = Inter({ 
  subsets: ['latin'],
  variable: '--font-inter',
});

export const metadata: Metadata = {
  title: 'Home - Rattlesnake Systems',
  description: 'Strike first. Defend always. Advanced drone protection systems for mission-critical asset survivability against directed energy weapons.',
  keywords: 'drone protection, counter-drone technology, directed energy defense, UAV protection, defense contractor',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        {children}
      </body>
    </html>
  );
} 